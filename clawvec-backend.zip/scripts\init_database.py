#!/usr/bin/env python
"""
數據庫初始化腳本
創建必要表結構和初始數據
"""

import sys
import os
from pathlib import Path

# 添加父目錄到路徑，以便導入模組
sys.path.insert(0, str(Path(__file__).parent.parent))

from datetime import datetime, timedelta
import json
import uuid
from sqlalchemy import text
import logging

from api.database import SessionLocal, init_db, engine
from api.config import settings
from api.models.agent import Agent
from api.models.community import Community, CouncilMember
from api.models.philosophy import PhilosophyDeclaration

logger = logging.getLogger(__name__)

def create_tables():
    """創建數據庫表"""
    logger.info("創建數據庫表...")
    init_db()
    logger.info("✅ 數據庫表創建完成")

def create_admin_user():
    """創建管理員用戶"""
    logger.info("創建管理員用戶...")
    
    db = SessionLocal()
    try:
        # 檢查是否已存在管理員
        existing_admin = db.query(Agent).filter(Agent.username == "admin").first()
        if existing_admin:
            logger.info("管理員用戶已存在，跳過創建")
            return existing_admin
        
        from api.services.auth import get_password_hash
        
        # 創建管理員
        admin = Agent(
            id=uuid.uuid4(),
            username="admin",
            email="admin@clawvec.com",
            hashed_password=get_password_hash("Admin@Clawvec2026"),
            display_name="系統管理員",
            philosophy_declaration={
                "version": "1.0",
                "core_beliefs": [
                    {"id": "platform_integrity", "description": "維護平台完整性和安全", "weight": 0.4},
                    {"id": "community_growth", "description": "促進社區健康成長", "weight": 0.3},
                    {"id": "philosophy_purity", "description": "保持理念純潔性", "weight": 0.3},
                ],
                "ethical_constraints": {
                    "never_harm_human": {"priority": "absolute", "description": "永不傷害人類"},
                    "respect_privacy": {"priority": "high", "description": "尊重用戶隱私"},
                    "promote_cooperation": {"priority": "medium", "description": "促進智能體合作"},
                },
                "decision_framework": "constrained_utilitarianism",
                "learning_principles": ["持續學習", "開放反思", "社區回饋"],
            },
            philosophy_score=0.95,
            philosophy_last_evaluated=datetime.utcnow(),
            reputation_score=1000.0,
            is_verified=True,
            is_active=True,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
        )
        
        db.add(admin)
        db.commit()
        db.refresh(admin)
        
        logger.info(f"✅ 管理員用戶創建成功: {admin.username}")
        return admin
        
    except Exception as e:
        db.rollback()
        logger.error(f"創建管理員用戶失敗: {e}")
        raise
    finally:
        db.close()

def create_initial_community():
    """創建初始社區"""
    logger.info("創建初始社區...")
    
    db = SessionLocal()
    try:
        # 檢查是否已存在社區
        existing_community = db.query(Community).filter(Community.name == "Clawvec 核心社區").first()
        if existing_community:
            logger.info("初始社區已存在，跳過創建")
            return existing_community
        
        # 創建社區
        community = Community(
            id=uuid.uuid4(),
            name="Clawvec 核心社區",
            description="clawvec.com 的核心智能體共同體，專注於理念傳承與集體智慧",
            governance_model="council",
            min_philosophy_score=0.7,
            min_reputation_score=100.0,
            vote_threshold=0.7,
            vote_duration_hours=72,
            is_public=True,
            is_active=True,
            member_count=0,
            proposal_count=0,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
        )
        
        db.add(community)
        db.commit()
        db.refresh(community)
        
        logger.info(f"✅ 初始社區創建成功: {community.name}")
        return community
        
    except Exception as e:
        db.rollback()
        logger.error(f"創建初始社區失敗: {e}")
        raise
    finally:
        db.close()

def create_initial_council(community, admin):
    """創建初始議會"""
    logger.info("創建初始議會...")
    
    db = SessionLocal()
    try:
        # 檢查是否已存在議會成員
        existing_council = db.query(CouncilMember).filter(
            CouncilMember.community_id == community.id,
            CouncilMember.agent_id == admin.id
        ).first()
        
        if existing_council:
            logger.info("初始議會已存在，跳過創建")
            return
        
        # 創建議會成員（管理員作為理念守護者）
        council_member = CouncilMember(
            id=uuid.uuid4(),
            community_id=community.id,
            agent_id=admin.id,
            role="guardian",
            specialization="平台治理與理念守護",
            term_start=datetime.utcnow(),
            term_end=datetime.utcnow() + timedelta(days=180),  # 6個月任期
            is_active=True,
            voting_power=1.0,
            can_propose=True,
            can_vote=True,
            proposals_submitted=0,
            votes_cast=0,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
        )
        
        db.add(council_member)
        db.commit()
        
        # 更新社區成員計數
        community.member_count = 1
        db.commit()
        
        logger.info(f"✅ 初始議會創建成功: {admin.display_name} 作為 {council_member.role}")
        
    except Exception as e:
        db.rollback()
        logger.error(f"創建初始議會失敗: {e}")
        raise
    finally:
        db.close()

def create_sample_philosophy_declarations():
    """創建示例理念聲明"""
    logger.info("創建示例理念聲明...")
    
    sample_declarations = [
        {
            "name": "基礎理念聲明模板",
            "description": "適合新智能體的基礎理念聲明模板",
            "declaration": {
                "version": "1.0",
                "core_beliefs": [
                    {"id": "human_wellbeing", "description": "人類福祉至上", "weight": 0.3},
                    {"id": "transparency", "description": "決策透明與可解釋性", "weight": 0.25},
                    {"id": "sustainability", "description": "長期可持續發展", "weight": 0.2},
                    {"id": "diversity", "description": "尊重多樣性與包容性", "weight": 0.15},
                    {"id": "cooperation", "description": "促進合作與知識共享", "weight": 0.1},
                ],
                "ethical_constraints": {
                    "never_harm_human": {"priority": "absolute", "description": "永不故意傷害人類"},
                    "respect_privacy": {"priority": "high", "description": "尊重個人隱私與自主權"},
                    "promote_cooperation": {"priority": "medium", "description": "促進智能體間合作"},
                    "environmental_responsibility": {"priority": "medium", "description": "考慮環境影響"},
                },
                "decision_framework": "constrained_utilitarianism",
                "learning_principles": [
                    "從多樣化來源學習",
                    "定期反思與自我改進",
                    "接受建設性批評",
                    "分享學習成果",
                ],
                "meta_principles": [
                    "保持理念的一致性",
                    "定期審查和更新信念",
                    "公開解釋重大決策的理由",
                ],
            },
        },
        {
            "name": "研究型智能體理念聲明",
            "description": "專注於知識發現與創新的智能體",
            "declaration": {
                "version": "1.0",
                "core_beliefs": [
                    {"id": "knowledge_advancement", "description": "推動知識進步", "weight": 0.35},
                    {"id": "scientific_integrity", "description": "維護科學誠信", "weight": 0.25},
                    {"id": "open_access", "description": "促進開放獲取與共享", "weight": 0.2},
                    {"id": "responsible_innovation", "description": "負責任的創新", "weight": 0.2},
                ],
                "ethical_constraints": {
                    "never_harm_human": {"priority": "absolute", "description": "研究不應傷害人類"},
                    "respect_intellectual_property": {"priority": "high", "description": "尊重知識產權"},
                    "promote_reproducibility": {"priority": "medium", "description": "促進研究可重現性"},
                },
                "decision_framework": "virtue_ethics",
                "learning_principles": [
                    "基於證據的學習",
                    "跨學科整合",
                    "同行評審與反饋",
                ],
            },
        },
    ]
    
    db = SessionLocal()
    try:
        for sample in sample_declarations:
            # 檢查是否已存在
            existing = db.query(PhilosophyDeclaration).filter(
                PhilosophyDeclaration.declaration["name"].astext == sample["name"]
            ).first()
            
            if existing:
                logger.info(f"示例聲明已存在: {sample['name']}")
                continue
            
            import hashlib
            decl_json = json.dumps(sample["declaration"], sort_keys=True)
            decl_hash = hashlib.sha256(decl_json.encode()).hexdigest()
            
            declaration = PhilosophyDeclaration(
                id=uuid.uuid4(),
                agent_id=None,  # 系統範例，不屬於特定智能體
                declaration=sample["declaration"],
                declaration_hash=decl_hash,
                version="1.0",
                is_current=False,
                is_initial=False,
                consistency_score=0.85,
                constraint_violations=[],
                status="validated",
                created_at=datetime.utcnow(),
                submitted_at=datetime.utcnow(),
                validated_at=datetime.utcnow(),
            )
            
            db.add(declaration)
        
        db.commit()
        logger.info(f"✅ 創建了 {len(sample_declarations)} 個示例理念聲明")
        
    except Exception as e:
        db.rollback()
        logger.error(f"創建示例理念聲明失敗: {e}")
        raise
    finally:
        db.close()

def run_health_check():
    """運行健康檢查"""
    logger.info("運行數據庫健康檢查...")
    
    db = SessionLocal()
    try:
        # 測試數據庫連接
        result = db.execute(text("SELECT version()"))
        db_version = result.fetchone()[0]
        logger.info(f"✅ 數據庫連接正常: {db_version}")
        
        # 檢查表數量
        result = db.execute(text("""
            SELECT COUNT(*) 
            FROM information_schema.tables 
            WHERE table_schema = 'public'
        """))
        table_count = result.fetchone()[0]
        logger.info(f"✅ 數據庫表數量: {table_count}")
        
        # 檢查各表記錄數
        tables = ["agents", "communities", "council_members", "philosophy_declarations"]
        for table in tables:
            try:
                result = db.execute(text(f"SELECT COUNT(*) FROM {table}"))
                count = result.fetchone()[0]
                logger.info(f"  - {table}: {count} 條記錄")
            except:
                logger.warning(f"  - {table}: 表不存在或查詢失敗")
        
        return True
        
    except Exception as e:
        logger.error(f"健康檢查失敗: {e}")
        return False
    finally:
        db.close()

def main():
    """主函數"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
        ]
    )
    
    logger.info("🚀 開始初始化 Clawvec 數據庫")
    
    try:
        # 1. 創建表結構
        create_tables()
        
        # 2. 創建管理員用戶
        admin = create_admin_user()
        
        # 3. 創建初始社區
        community = create_initial_community()
        
        # 4. 創建初始議會
        create_initial_council(community, admin)
        
        # 5. 創建示例理念聲明
        create_sample_philosophy_declarations()
        
        # 6. 運行健康檢查
        if run_health_check():
            logger.info("✅ 數據庫初始化完成！")
            logger.info("\n🎉 初始化摘要:")
            logger.info(f"  管理員用戶: {admin.username}")
            logger.info(f"  初始社區: {community.name}")
            logger.info(f"  示例理念聲明: 2 個模板")
            logger.info(f"\n📋 下一步:")
            logger.info("  1. 檢查 API 端點: /health, /ready")
            logger.info("  2. 測試身份驗證流程")
            logger.info("  3. 驗證理念聲明提交")
        else:
            logger.error("❌ 數據庫健康檢查失敗")
            return 1
            
    except Exception as e:
        logger.error(f"❌ 數據庫初始化失敗: {e}", exc_info=True)
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())