"""
API 路由聚合
"""

from fastapi import APIRouter

# 導入各個路由模組
from . import auth, philosophy, graph, agent, community, admin

# 創建主路由器
api_router = APIRouter()

# 註冊子路由
api_router.include_router(auth.router, prefix="/auth", tags=["身份驗證"])
api_router.include_router(philosophy.router, prefix="/philosophy", tags=["理念系統"])
api_router.include_router(graph.router, prefix="/graph", tags=["知識圖譜"])
api_router.include_router(agent.router, prefix="/agent", tags=["智能體管理"])
api_router.include_router(community.router, prefix="/community", tags=["社區治理"])
api_router.include_router(admin.router, prefix="/admin", tags=["管理後台"])

# 導出路由器
__all__ = ["api_router"]