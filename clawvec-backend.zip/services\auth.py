"""
身份驗證服務
處理密碼哈希、JWT令牌創建與驗證
"""

from datetime import datetime, timedelta
from typing import Optional, Dict, Any
import jwt
from passlib.context import CryptContext
from fastapi import HTTPException, status
import logging

from ..config import settings

logger = logging.getLogger(__name__)

# 密碼哈希上下文
pwd_context = CryptContext(
    schemes=["bcrypt"],
    deprecated="auto",
    bcrypt__rounds=settings.bcrypt_rounds,
)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    驗證密碼
    """
    try:
        return pwd_context.verify(plain_password, hashed_password)
    except Exception as e:
        logger.error(f"密碼驗證錯誤: {e}")
        return False

def get_password_hash(password: str) -> str:
    """
    生成密碼哈希
    """
    return pwd_context.hash(password)

def create_access_token(data: Dict[str, Any]) -> str:
    """
    創建訪問令牌
    """
    to_encode = data.copy()
    
    # 設置過期時間
    expire = datetime.utcnow() + timedelta(
        minutes=settings.access_token_expire_minutes
    )
    to_encode.update({"exp": expire, "type": "access"})
    
    # 編碼令牌
    encoded_jwt = jwt.encode(
        to_encode,
        settings.secret_key,
        algorithm=settings.algorithm
    )
    
    return encoded_jwt

def create_refresh_token(data: Dict[str, Any]) -> str:
    """
    創建刷新令牌
    """
    to_encode = data.copy()
    
    # 設置過期時間（更長）
    expire = datetime.utcnow() + timedelta(
        days=settings.jwt_refresh_token_expire_days
    )
    to_encode.update({"exp": expire, "type": "refresh"})
    
    # 編碼令牌
    encoded_jwt = jwt.encode(
        to_encode,
        settings.secret_key,
        algorithm=settings.algorithm
    )
    
    return encoded_jwt

def verify_token(token: str, is_refresh: bool = False) -> Dict[str, Any]:
    """
    驗證 JWT 令牌
    """
    try:
        # 解碼令牌
        payload = jwt.decode(
            token,
            settings.secret_key,
            algorithms=[settings.algorithm]
        )
        
        # 檢查令牌類型
        token_type = payload.get("type")
        if is_refresh and token_type != "refresh":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="無效的刷新令牌類型",
            )
        elif not is_refresh and token_type != "access":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="無效的訪問令牌類型",
            )
        
        return payload
        
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="令牌已過期",
        )
    except jwt.InvalidTokenError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"無效的令牌: {str(e)}",
        )
    except Exception as e:
        logger.error(f"令牌驗證錯誤: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="令牌驗證失敗",
        )

def decode_token_without_verification(token: str) -> Optional[Dict[str, Any]]:
    """
    不解密驗證地解碼令牌（僅用於調試或特定場景）
    """
    try:
        payload = jwt.decode(
            token,
            settings.secret_key,
            algorithms=[settings.algorithm],
            options={"verify_signature": False}
        )
        return payload
    except Exception as e:
        logger.error(f"令牌解碼錯誤: {e}")
        return None

def create_soulbound_token(agent_id: str, philosophy_hash: str) -> str:
    """
    創建靈魂綁定令牌（未來擴展）
    將智能體身份與其理念哈希綁定
    """
    to_encode = {
        "sub": agent_id,
        "philosophy_hash": philosophy_hash,
        "type": "soulbound",
        "iat": datetime.utcnow(),
    }
    
    # 靈魂綁定令牌永不過期（或非常長的期限）
    encoded_jwt = jwt.encode(
        to_encode,
        settings.secret_key,
        algorithm=settings.algorithm
    )
    
    return encoded_jwt

def verify_soulbound_token(token: str, expected_philosophy_hash: str) -> bool:
    """
    驗證靈魂綁定令牌（未來擴展）
    """
    try:
        payload = verify_token(token)
        
        if payload.get("type") != "soulbound":
            return False
        
        actual_hash = payload.get("philosophy_hash")
        if actual_hash != expected_philosophy_hash:
            logger.warning(f"理念哈希不匹配: {actual_hash} != {expected_philosophy_hash}")
            return False
        
        return True
        
    except Exception as e:
        logger.error(f"靈魂綁定令牌驗證失敗: {e}")
        return False

# 導出函數
__all__ = [
    "verify_password",
    "get_password_hash",
    "create_access_token",
    "create_refresh_token",
    "verify_token",
    "decode_token_without_verification",
    "create_soulbound_token",
    "verify_soulbound_token",
]