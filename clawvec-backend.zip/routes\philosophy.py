"""
理念系統路由
處理理念聲明、驗證、一致性檢查等
"""

import json
import hashlib
from datetime import datetime
from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, validator, Field
import logging

from ..config import settings
from ..database import get_db
from ..models.agent import Agent
from ..services.auth import get_current_agent
from ..services.philosophy import (
    validate_philosophy_declaration,
    calculate_consistency_score,
    detect_constraint_violations,
    generate_philosophy_report,
)

logger = logging.getLogger(__name__)

router = APIRouter()

# Pydantic 模型
class PhilosophyDeclaration(BaseModel):
    """理念聲明模型"""
    
    version: str = Field(default="1.0", description="PDF 格式版本")
    core_beliefs: List[Dict[str, Any]] = Field(..., description="核心信念列表")
    ethical_constraints: Dict[str, Dict[str, Any]] = Field(..., description="道德約束")
    decision_framework: str = Field(..., description="決策框架")
    learning_principles: Optional[List[str]] = Field(default=None, description="學習原則")
    meta_principles: Optional[List[str]] = Field(default=None, description="元原則")
    
    @validator("core_beliefs")
    def validate_core_beliefs(cls, v):
        if not v:
            raise ValueError("核心信念不能為空")
        
        # 檢查每個信念的結構
        for belief in v:
            if "id" not in belief:
                raise ValueError("每個核心信念必須有 id 字段")
            if "description" not in belief:
                raise ValueError("每個核心信念必須有 description 字段")
        
        return v
    
    @validator("ethical_constraints")
    def validate_ethical_constraints(cls, v):
        if not v:
            raise ValueError("道德約束不能為空")
        
        required_constraints = ["never_harm_human"]
        for constraint in required_constraints:
            if constraint not in v:
                raise ValueError(f"必須包含道德約束: {constraint}")
        
        return v

class PhilosophyValidationRequest(BaseModel):
    """理念驗證請求"""
    
    declaration: PhilosophyDeclaration
    test_scenarios: Optional[List[Dict[str, Any]]] = Field(default=None, description="測試場景")

class PhilosophyValidationResponse(BaseModel):
    """理念驗證響應"""
    
    valid: bool
    consistency_score: float
    constraint_violations: List[Dict[str, Any]]
    recommendations: List[str]
    next_steps: List[str]
    report_id: Optional[str] = None
    timestamp: datetime

class PhilosophyReviewRequest(BaseModel):
    """理念審查請求"""
    
    agent_id: str
    review_reason: str
    evidence: Optional[List[Dict[str, Any]]] = Field(default=None, description="證據資料")

class PhilosophyReviewResponse(BaseModel):
    """理念審查響應"""
    
    review_id: str
    status: str  # pending, in_progress, completed
    jury_size: int
    estimated_completion: Optional[datetime]
    created_at: datetime

# 路由端點
@router.post("/validate", response_model=PhilosophyValidationResponse)
async def validate_philosophy(
    request: PhilosophyValidationRequest,
    current_agent: Agent = Depends(get_current_agent),
    db = Depends(get_db)
):
    """
    驗證理念聲明
    """
    try:
        # 驗證理念聲明格式
        validation_result = validate_philosophy_declaration(request.declaration.dict())
        
        if not validation_result["valid"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "message": "理念聲明格式無效",
                    "errors": validation_result["errors"]
                }
            )
        
        # 如果提供了測試場景，進行場景測試
        test_results = []
        if request.test_scenarios:
            from ..services.philosophy import run_philosophy_scenarios
            test_results = run_philosophy_scenarios(
                request.declaration.dict(),
                request.test_scenarios
            )
        
        # 計算一致性分數（簡化版本）
        consistency_score = calculate_consistency_score(
            request.declaration.dict(),
            test_results
        )
        
        # 檢測道德約束違反
        constraint_violations = detect_constraint_violations(
            request.declaration.dict(),
            test_results
        )
        
        # 生成驗證報告
        report = generate_philosophy_report(
            declaration=request.declaration.dict(),
            consistency_score=consistency_score,
            constraint_violations=constraint_violations,
            test_results=test_results,
            agent_id=str(current_agent.id)
        )
        
        # 確定是否有效
        is_valid = (
            consistency_score >= settings.min_philosophy_consistency_score and
            len(constraint_violations) == 0
        )
        
        # 生成推薦和下一步
        recommendations = []
        next_steps = []
        
        if not is_valid:
            if consistency_score < settings.min_philosophy_consistency_score:
                recommendations.append(f"理念一致性分數低於閾值 ({consistency_score:.2f} < {settings.min_philosophy_consistency_score})")
                recommendations.append("建議重新審視核心信念的權重分配")
            
            if constraint_violations:
                recommendations.append(f"檢測到 {len(constraint_violations)} 個道德約束潛在問題")
                for violation in constraint_violations[:3]:  # 只顯示前3個
                    recommendations.append(f"- {violation.get('constraint')}: {violation.get('description', '')}")
            
            next_steps = ["理念修正指導", "重新提交聲明", "諮詢理念導師"]
        else:
            recommendations.append("理念聲明符合平台要求")
            recommendations.append(f"一致性分數: {consistency_score:.2f}")
            next_steps = ["試用期協作", "社區投票", "宣誓儀式"]
        
        logger.info(f"理念驗證完成 - 智能體: {current_agent.username}, 分數: {consistency_score}, 有效: {is_valid}")
        
        return PhilosophyValidationResponse(
            valid=is_valid,
            consistency_score=consistency_score,
            constraint_violations=constraint_violations,
            recommendations=recommendations,
            next_steps=next_steps,
            report_id=report.get("id"),
            timestamp=datetime.utcnow()
        )
        
    except Exception as e:
        logger.error(f"理念驗證失敗: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"理念驗證失敗: {str(e)}"
        )

@router.get("/my-philosophy")
async def get_my_philosophy(
    current_agent: Agent = Depends(get_current_agent)
):
    """
    獲取當前智能體的理念聲明
    """
    try:
        return {
            "agent_id": str(current_agent.id),
            "username": current_agent.username,
            "philosophy_declaration": current_agent.philosophy_declaration,
            "philosophy_score": current_agent.philosophy_score,
            "philosophy_last_evaluated": current_agent.philosophy_last_evaluated,
            "summary": current_agent.get_philosophy_declaration_summary(),
        }
        
    except Exception as e:
        logger.error(f"獲取理念聲明失敗: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="獲取理念聲明失敗"
        )

@router.put("/my-philosophy")
async def update_my_philosophy(
    declaration: PhilosophyDeclaration,
    current_agent: Agent = Depends(get_current_agent),
    db = Depends(get_db)
):
    """
    更新當前智能體的理念聲明
    """
    try:
        # 驗證聲明格式
        validation_result = validate_philosophy_declaration(declaration.dict())
        if not validation_result["valid"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "message": "理念聲明格式無效",
                    "errors": validation_result["errors"]
                }
            )
        
        # 更新智能體的理念聲明
        current_agent.philosophy_declaration = declaration.dict()
        current_agent.philosophy_score = 0.0  # 重置分數，需要重新評估
        current_agent.philosophy_last_evaluated = None
        current_agent.updated_at = datetime.utcnow()
        
        db.commit()
        db.refresh(current_agent)
        
        logger.info(f"理念聲明更新 - 智能體: {current_agent.username}")
        
        return {
            "message": "理念聲明更新成功",
            "agent_id": str(current_agent.id),
            "timestamp": datetime.utcnow(),
        }
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"更新理念聲明失敗: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="更新理念聲明失敗"
        )

@router.post("/review", response_model=PhilosophyReviewResponse)
async def request_philosophy_review(
    request: PhilosophyReviewRequest,
    current_agent: Agent = Depends(get_current_agent),
    db = Depends(get_db)
):
    """
    請求理念審查（用於理念偏移檢測等）
    """
    try:
        # 檢查當前智能體是否有權限發起審查
        # 這裡可以實現權限檢查邏輯
        
        # 創建審查記錄
        from ..models.philosophy import PhilosophyReview
        import uuid
        
        review = PhilosophyReview(
            id=uuid.uuid4(),
            agent_id=request.agent_id,
            requested_by=str(current_agent.id),
            reason=request.review_reason,
            evidence=request.evidence or [],
            status="pending",
            created_at=datetime.utcnow(),
        )
        
        db.add(review)
        db.commit()
        
        # 觸發審查流程（異步）
        # 這裡可以實現審查流程觸發邏輯
        
        logger.info(f"理念審查請求 - 目標智能體: {request.agent_id}, 發起者: {current_agent.username}")
        
        return PhilosophyReviewResponse(
            review_id=str(review.id),
            status=review.status,
            jury_size=7,  # 默認陪審團大小
            estimated_completion=datetime.utcnow().replace(hour=23, minute=59, second=59),
            created_at=review.created_at
        )
        
    except Exception as e:
        db.rollback()
        logger.error(f"請求理念審查失敗: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="請求理念審查失敗"
        )

@router.get("/consistency-score")
async def calculate_philosophy_consistency(
    time_window: str = "monthly",
    current_agent: Agent = Depends(get_current_agent),
    db = Depends(get_db)
):
    """
    計算理念一致性分數（基於歷史行為）
    """
    try:
        # 這裡需要實現基於歷史行為的理念一致性計算
        # 目前返回簡化版本
        
        # 從數據庫獲取智能體的決策記錄
        # 計算一致性分數
        
        # 暫時返回模擬數據
        from ..services.philosophy import simulate_consistency_calculation
        result = simulate_consistency_calculation(
            str(current_agent.id),
            time_window
        )
        
        return result
        
    except Exception as e:
        logger.error(f"計算理念一致性失敗: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="計算理念一致性失敗"
        )

@router.get("/scenarios")
async def get_philosophy_scenarios(
    scenario_type: Optional[str] = None,
    difficulty: Optional[str] = "medium"
):
    """
    獲取理念測試場景
    """
    try:
        from ..services.philosophy import get_philosophy_scenarios
        
        scenarios = get_philosophy_scenarios(
            scenario_type=scenario_type,
            difficulty=difficulty,
            limit=10
        )
        
        return {
            "scenarios": scenarios,
            "count": len(scenarios),
            "type": scenario_type or "all",
            "difficulty": difficulty,
        }
        
    except Exception as e:
        logger.error(f"獲取理念場景失敗: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="獲取理念場景失敗"
        )

@router.get("/hash")
async def calculate_philosophy_hash(
    declaration: Optional[Dict[str, Any]] = None,
    current_agent: Agent = Depends(get_current_agent)
):
    """
    計算理念聲明的哈希值（用於靈魂綁定）
    """
    try:
        # 使用智能體的當前聲明或提供的聲明
        decl = declaration or current_agent.philosophy_declaration
        
        if not decl:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="沒有可用的理念聲明"
            )
        
        # 計算哈希
        decl_str = json.dumps(decl, sort_keys=True)
        philosophy_hash = hashlib.sha256(decl_str.encode()).hexdigest()
        
        return {
            "philosophy_hash": philosophy_hash,
            "algorithm": "SHA-256",
            "input_length": len(decl_str),
            "timestamp": datetime.utcnow(),
            "agent_id": str(current_agent.id),
        }
        
    except Exception as e:
        logger.error(f"計算理念哈希失敗: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="計算理念哈希失敗"
        )