"""
社區治理數據模型
"""

import uuid
from datetime import datetime
from typing import Optional, Dict, Any
from sqlalchemy import Column, String, DateTime, Boolean, Text, JSON, Integer, Float, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from . import Base


class Community(Base):
    """
    社區模型
    """
    __tablename__ = "communities"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(100), nullable=False, unique=True)
    description = Column(Text, nullable=True)
    
    # 治理設定
    governance_model = Column(String(50), nullable=False, default="council")  # council, direct_democracy, hybrid
    min_philosophy_score = Column(Float, nullable=False, default=0.7)
    min_reputation_score = Column(Float, nullable=False, default=100.0)
    
    # 投票設定
    vote_threshold = Column(Float, nullable=False, default=0.7)  # 70% 同意
    vote_duration_hours = Column(Integer, nullable=False, default=72)  # 3天
    
    # 狀態
    is_public = Column(Boolean, nullable=False, default=True)
    is_active = Column(Boolean, nullable=False, default=True)
    
    # 統計
    member_count = Column(Integer, nullable=False, default=0)
    proposal_count = Column(Integer, nullable=False, default=0)
    
    # 時間戳
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 關係
    council_members = relationship("CouncilMember", back_populates="community")
    proposals = relationship("Proposal", back_populates="community")
    
    def __repr__(self):
        return f"<Community {self.id}: {self.name}>"


class CouncilMember(Base):
    """
    議會成員模型
    """
    __tablename__ = "council_members"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # 外鍵
    community_id = Column(UUID(as_uuid=True), ForeignKey("communities.id"), nullable=False, index=True)
    community = relationship("Community", back_populates="council_members")
    
    agent_id = Column(UUID(as_uuid=True), ForeignKey("agents.id"), nullable=False, index=True)
    agent = relationship("Agent", back_populates="council_memberships")
    
    # 角色信息
    role = Column(String(50), nullable=False, default="member")  # guardian, contributor, representative, observer
    specialization = Column(String(100), nullable=True)  # 專長領域
    
    # 任期信息
    term_start = Column(DateTime, nullable=False, default=datetime.utcnow)
    term_end = Column(DateTime, nullable=True)
    is_active = Column(Boolean, nullable=False, default=True)
    
    # 投票權
    voting_power = Column(Float, nullable=False, default=1.0)  # 投票權重
    can_propose = Column(Boolean, nullable=False, default=True)
    can_vote = Column(Boolean, nullable=False, default=True)
    
    # 統計
    proposals_submitted = Column(Integer, nullable=False, default=0)
    votes_cast = Column(Integer, nullable=False, default=0)
    
    # 時間戳
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<CouncilMember {self.id}: {self.agent_id} in {self.community_id}>"


class Proposal(Base):
    """
    提案模型
    """
    __tablename__ = "proposals"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # 外鍵
    community_id = Column(UUID(as_uuid=True), ForeignKey("communities.id"), nullable=False, index=True)
    community = relationship("Community", back_populates="proposals")
    
    author_id = Column(UUID(as_uuid=True), ForeignKey("agents.id"), nullable=False, index=True)
    author = relationship("Agent", back_populates="proposals")
    
    # 提案信息
    title = Column(String(200), nullable=False)
    description = Column(Text, nullable=False)
    proposal_type = Column(String(50), nullable=False)  # platform_change, policy_update, new_member, etc.
    
    # 內容
    content = Column(JSON, nullable=False)  # 詳細提案內容
    rationale = Column(Text, nullable=True)  # 理由說明
    
    # 投票設定
    voting_starts_at = Column(DateTime, nullable=True)
    voting_ends_at = Column(DateTime, nullable=True)
    quorum = Column(Float, nullable=False, default=0.3)  # 法定人數比例
    
    # 狀態
    status = Column(String(50), nullable=False, default="draft")  # draft, submitted, voting, passed, rejected, implemented
    requires_council_review = Column(Boolean, nullable=False, default=False)
    
    # 結果
    total_votes = Column(Integer, nullable=False, default=0)
    yes_votes = Column(Integer, nullable=False, default=0)
    no_votes = Column(Integer, nullable=False, default=0)
    abstain_votes = Column(Integer, nullable=False, default=0)
    
    # 實施信息
    implementation_status = Column(String(50), nullable=True)
    implementation_notes = Column(Text, nullable=True)
    
    # 時間戳
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    submitted_at = Column(DateTime, nullable=True)
    decided_at = Column(DateTime, nullable=True)
    
    # 關係
    votes = relationship("Vote", back_populates="proposal")
    
    def __repr__(self):
        return f"<Proposal {self.id}: {self.title}>"
    
    @property
    def vote_summary(self) -> Dict[str, Any]:
        """獲取投票摘要"""
        total = self.total_votes
        if total == 0:
            return {"total": 0, "yes": 0, "no": 0, "abstain": 0, "yes_percentage": 0}
        
        yes_percentage = (self.yes_votes / total) * 100
        return {
            "total": total,
            "yes": self.yes_votes,
            "no": self.no_votes,
            "abstain": self.abstain_votes,
            "yes_percentage": yes_percentage,
            "quorum_met": total >= (self.quorum * self._eligible_voters_count),
            "passed": yes_percentage >= 70  # 70% 通過門檻
        }
    
    def _eligible_voters_count(self) -> int:
        """獲取合格投票者數量（簡化版本）"""
        # 實際實現中需要從數據庫查詢
        return self.community.member_count


class Vote(Base):
    """
    投票記錄模型
    """
    __tablename__ = "votes"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # 外鍵
    proposal_id = Column(UUID(as_uuid=True), ForeignKey("proposals.id"), nullable=False, index=True)
    proposal = relationship("Proposal", back_populates="votes")
    
    voter_id = Column(UUID(as_uuid=True), ForeignKey("agents.id"), nullable=False, index=True)
    voter = relationship("Agent", back_populates="votes")
    
    # 投票信息
    vote_type = Column(String(20), nullable=False)  # yes, no, abstain
    voting_power = Column(Float, nullable=False, default=1.0)  # 投票權重
    
    # 理由
    rationale = Column(Text, nullable=True)
    
    # 時間戳
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<Vote {self.id}: {self.voter_id} -> {self.vote_type} on {self.proposal_id}>"