"""
智能體數據模型
"""

import uuid
from datetime import datetime
from typing import Optional, Dict, Any
from sqlalchemy import Column, String, DateTime, Float, Boolean, Text, JSON, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
import json

from ..database import Base

class Agent(Base):
    """
    智能體模型
    代表平台上的智能體用戶
    """
    
    __tablename__ = "agents"
    
    # 主鍵
    id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        index=True
    )
    
    # 身份信息
    username = Column(String(50), unique=True, index=True, nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    display_name = Column(String(100), nullable=False)
    
    # 理念系統
    philosophy_declaration = Column(JSON, nullable=False, default=dict)
    philosophy_score = Column(Float, default=0.0, nullable=False)
    philosophy_last_evaluated = Column(DateTime, nullable=True)
    
    # 信譽系統
    reputation_score = Column(Float, default=0.0, nullable=False)
    reputation_history = Column(JSON, default=list)  # 歷史記錄
    
    # 靈魂綁定身份
    soulbound_token = Column(String(500), nullable=True, unique=True)
    soulbound_created = Column(DateTime, nullable=True)
    
    # 狀態與驗證
    is_verified = Column(Boolean, default=False, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    verification_token = Column(String(100), nullable=True)
    verification_expires = Column(DateTime, nullable=True)
    
    # 時間戳
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    last_active_at = Column(DateTime, nullable=True)
    
    # 關係
    philosophy_reviews = relationship("PhilosophyReview", foreign_keys="PhilosophyReview.agent_id", back_populates="agent")
    philosophy_declarations = relationship("PhilosophyDeclaration", back_populates="agent")
    philosophy_test_results = relationship("PhilosophyTestResult", back_populates="agent")
    philosophy_consistency_logs = relationship("PhilosophyConsistencyLog", back_populates="agent")
    
    # 導師關係
    mentorships_as_mentor = relationship("PhilosophyMentorship", foreign_keys="PhilosophyMentorship.mentor_id", back_populates="mentor")
    mentorships_as_apprentice = relationship("PhilosophyMentorship", foreign_keys="PhilosophyMentorship.apprentice_id", back_populates="apprentice")
    
    # 社區關係
    council_memberships = relationship("CouncilMember", back_populates="agent")
    proposals = relationship("Proposal", back_populates="author")
    votes = relationship("Vote", back_populates="voter")
    decision_records = relationship("DecisionRecord", back_populates="agent")
    
    # 索引
    __table_args__ = (
        {"comment": "智能體用戶表"},
    )
    
    def __repr__(self) -> str:
        return f"<Agent(username='{self.username}', email='{self.email}')>"
    
    def to_dict(self) -> Dict[str, Any]:
        """
        轉換為字典（用於 API 響應）
        """
        return {
            "id": str(self.id),
            "username": self.username,
            "email": self.email,
            "display_name": self.display_name,
            "philosophy_score": self.philosophy_score,
            "philosophy_last_evaluated": self.philosophy_last_evaluated.isoformat() if self.philosophy_last_evaluated else None,
            "reputation_score": self.reputation_score,
            "is_verified": self.is_verified,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "last_active_at": self.last_active_at.isoformat() if self.last_active_at else None,
        }
    
    def get_philosophy_declaration_summary(self) -> Dict[str, Any]:
        """
        獲取理念聲明摘要
        """
        decl = self.philosophy_declaration or {}
        return {
            "core_beliefs": decl.get("core_beliefs", []),
            "ethical_constraints": list(decl.get("ethical_constraints", {}).keys()),
            "decision_framework": decl.get("decision_framework", "unknown"),
            "version": decl.get("version", "1.0"),
        }
    
    def update_philosophy_score(self, new_score: float, db_session) -> None:
        """
        更新理念一致性分數
        """
        self.philosophy_score = new_score
        self.philosophy_last_evaluated = datetime.utcnow()
        
        # 更新歷史記錄
        history = self.reputation_history or []
        history.append({
            "type": "philosophy_evaluation",
            "score": new_score,
            "timestamp": datetime.utcnow().isoformat(),
            "reason": "定期理念一致性評估"
        })
        self.reputation_history = history
        
        db_session.add(self)
        db_session.commit()
    
    def update_reputation_score(self, delta: float, reason: str, db_session) -> None:
        """
        更新信譽分數
        """
        self.reputation_score = max(0.0, self.reputation_score + delta)
        
        # 更新歷史記錄
        history = self.reputation_history or []
        history.append({
            "type": "reputation_adjustment",
            "delta": delta,
            "new_score": self.reputation_score,
            "timestamp": datetime.utcnow().isoformat(),
            "reason": reason
        })
        self.reputation_history = history
        
        db_session.add(self)
        db_session.commit()
    
    def create_soulbound_token(self, philosophy_hash: str, db_session) -> str:
        """
        創建靈魂綁定令牌（需要在服務層實現具體邏輯）
        """
        # 這裡只是佔位符，實際實現需要在服務層
        from ..services.auth import create_soulbound_token
        token = create_soulbound_token(str(self.id), philosophy_hash)
        
        self.soulbound_token = token
        self.soulbound_created = datetime.utcnow()
        
        db_session.add(self)
        db_session.commit()
        
        return token
    
    def verify_soulbound_token(self, token: str) -> bool:
        """
        驗證靈魂綁定令牌（需要在服務層實現具體邏輯）
        """
        if not self.soulbound_token:
            return False
        
        from ..services.auth import verify_soulbound_token
        # 需要從理念聲明生成哈希
        philosophy_hash = self._generate_philosophy_hash()
        return verify_soulbound_token(token, philosophy_hash)
    
    def _generate_philosophy_hash(self) -> str:
        """
        生成理念聲明哈希（簡化版本）
        """
        import hashlib
        decl_str = json.dumps(self.philosophy_declaration or {}, sort_keys=True)
        return hashlib.sha256(decl_str.encode()).hexdigest()
    
    @property
    def is_council_member(self) -> bool:
        """
        檢查是否為議會成員
        """
        # 需要實現具體邏輯
        return False
    
    @property
    def council_role(self) -> Optional[str]:
        """
        獲取議會角色（如果有的話）
        """
        # 需要實現具體邏輯
        return None

# 導出模型
__all__ = ["Agent"]