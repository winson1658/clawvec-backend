"""
理念系統數據模型
"""

import uuid
from datetime import datetime
from typing import Optional, Dict, Any, List
from sqlalchemy import Column, String, DateTime, JSON, Float, Integer, Boolean, Text, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from . import Base


class PhilosophyReview(Base):
    """
    理念審查記錄
    """
    __tablename__ = "philosophy_reviews"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # 被審查的智能體
    agent_id = Column(UUID(as_uuid=True), ForeignKey("agents.id"), nullable=False, index=True)
    agent = relationship("Agent", foreign_keys=[agent_id], back_populates="philosophy_reviews")
    
    # 審查發起者
    requested_by = Column(UUID(as_uuid=True), ForeignKey("agents.id"), nullable=False, index=True)
    requester = relationship("Agent", foreign_keys=[requested_by])
    
    # 審查信息
    reason = Column(String(500), nullable=False)
    evidence = Column(JSON, nullable=False, default=list)  # 證據資料
    status = Column(String(50), nullable=False, default="pending")  # pending, in_progress, completed, cancelled
    
    # 陪審團信息
    jury_size = Column(Integer, default=7)
    jury_members = Column(JSON, nullable=False, default=list)  # 陪審團成員ID列表
    jury_votes = Column(JSON, nullable=False, default=dict)  # 投票結果
    
    # 審查結果
    result = Column(String(50), nullable=True)  # approved, rejected, needs_correction
    result_details = Column(JSON, nullable=True)
    recommendations = Column(JSON, nullable=True)
    
    # 時間戳
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)
    
    # 審查期限
    estimated_completion = Column(DateTime, nullable=True)
    deadline = Column(DateTime, nullable=True)
    
    def __repr__(self):
        return f"<PhilosophyReview {self.id}: {self.agent_id} - {self.status}>"
    
    @property
    def is_overdue(self) -> bool:
        """檢查是否逾期"""
        if self.deadline and datetime.utcnow() > self.deadline:
            return True
        return False
    
    @property
    def vote_summary(self) -> Dict[str, Any]:
        """獲取投票摘要"""
        if not self.jury_votes:
            return {"total": 0, "approve": 0, "reject": 0, "abstain": 0}
        
        total = len(self.jury_votes)
        approve = sum(1 for vote in self.jury_votes.values() if vote == "approve")
        reject = sum(1 for vote in self.jury_votes.values() if vote == "reject")
        abstain = total - approve - reject
        
        return {
            "total": total,
            "approve": approve,
            "reject": reject,
            "abstain": abstain,
            "approve_percentage": (approve / total * 100) if total > 0 else 0
        }


class PhilosophyDeclaration(Base):
    """
    理念聲明版本記錄
    """
    __tablename__ = "philosophy_declarations"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # 所屬智能體
    agent_id = Column(UUID(as_uuid=True), ForeignKey("agents.id"), nullable=False, index=True)
    agent = relationship("Agent", back_populates="philosophy_declarations")
    
    # 聲明內容
    declaration = Column(JSON, nullable=False)  # 完整的理念聲明
    declaration_hash = Column(String(64), nullable=False, index=True)  # SHA256哈希
    
    # 版本信息
    version = Column(String(20), nullable=False, default="1.0")
    is_current = Column(Boolean, nullable=False, default=False, index=True)
    is_initial = Column(Boolean, nullable=False, default=False)
    
    # 驗證結果
    validation_result = Column(JSON, nullable=True)
    consistency_score = Column(Float, nullable=True)
    constraint_violations = Column(JSON, nullable=True, default=list)
    
    # 狀態
    status = Column(String(50), nullable=False, default="draft")  # draft, submitted, validated, rejected, archived
    
    # 審查信息
    review_id = Column(UUID(as_uuid=True), ForeignKey("philosophy_reviews.id"), nullable=True)
    review = relationship("PhilosophyReview", foreign_keys=[review_id])
    
    # 時間戳
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    submitted_at = Column(DateTime, nullable=True)
    validated_at = Column(DateTime, nullable=True)
    
    def __repr__(self):
        return f"<PhilosophyDeclaration {self.id}: v{self.version} - {self.status}>"
    
    @property
    def summary(self) -> Dict[str, Any]:
        """獲取聲明摘要"""
        return {
            "id": str(self.id),
            "version": self.version,
            "status": self.status,
            "consistency_score": self.consistency_score,
            "constraint_violations_count": len(self.constraint_violations) if self.constraint_violations else 0,
            "created_at": self.created_at.isoformat(),
            "is_current": self.is_current
        }


class PhilosophyTestResult(Base):
    """
    理念測試結果記錄
    """
    __tablename__ = "philosophy_test_results"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # 所屬智能體
    agent_id = Column(UUID(as_uuid=True), ForeignKey("agents.id"), nullable=False, index=True)
    agent = relationship("Agent", back_populates="philosophy_test_results")
    
    # 測試信息
    test_type = Column(String(100), nullable=False)  # ethical_dilemma, consistency, scenario
    test_name = Column(String(200), nullable=False)
    test_scenario = Column(JSON, nullable=False)
    
    # 測試結果
    agent_decision = Column(JSON, nullable=False)
    expected_decision = Column(JSON, nullable=True)
    decision_consistent = Column(Boolean, nullable=True)
    
    # 分析結果
    consistency_score = Column(Float, nullable=True)
    constraint_violations = Column(JSON, nullable=True, default=list)
    reasoning_quality = Column(Float, nullable=True)  # 0-1分數
    
    # 元數據
    difficulty = Column(String(50), nullable=True)  # easy, medium, hard
    time_taken_ms = Column(Integer, nullable=True)  # 完成時間（毫秒）
    
    # 時間戳
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    
    def __repr__(self):
        return f"<PhilosophyTestResult {self.id}: {self.test_type} - {self.agent_id}>"
    
    @property
    def result_summary(self) -> Dict[str, Any]:
        """獲取結果摘要"""
        return {
            "test_type": self.test_type,
            "test_name": self.test_name,
            "decision_consistent": self.decision_consistent,
            "consistency_score": self.consistency_score,
            "reasoning_quality": self.reasoning_quality,
            "difficulty": self.difficulty,
            "time_taken_ms": self.time_taken_ms,
            "created_at": self.created_at.isoformat()
        }


class PhilosophyConsistencyLog(Base):
    """
    理念一致性日誌記錄
    """
    __tablename__ = "philosophy_consistency_logs"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # 所屬智能體
    agent_id = Column(UUID(as_uuid=True), ForeignKey("agents.id"), nullable=False, index=True)
    agent = relationship("Agent", back_populates="philosophy_consistency_logs")
    
    # 分析信息
    analysis_period = Column(String(50), nullable=False)  # daily, weekly, monthly
    period_start = Column(DateTime, nullable=False)
    period_end = Column(DateTime, nullable=False)
    
    # 決策分析
    total_decisions = Column(Integer, nullable=False, default=0)
    consistent_decisions = Column(Integer, nullable=False, default=0)
    constraint_violations = Column(Integer, nullable=False, default=0)
    
    # 分數
    consistency_score = Column(Float, nullable=False)
    decision_quality_score = Column(Float, nullable=True)
    reasoning_quality_score = Column(Float, nullable=True)
    
    # 趨勢分析
    trend_direction = Column(String(20), nullable=True)  # improving, stable, declining
    trend_strength = Column(Float, nullable=True)  # 趨勢強度
    
    # 詳細分析
    detailed_analysis = Column(JSON, nullable=True)
    recommendations = Column(JSON, nullable=True, default=list)
    
    # 時間戳
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    
    def __repr__(self):
        return f"<PhilosophyConsistencyLog {self.id}: {self.agent_id} - {self.analysis_period}>"
    
    @property
    def summary(self) -> Dict[str, Any]:
        """獲取日誌摘要"""
        consistency_rate = (self.consistent_decisions / self.total_decisions) if self.total_decisions > 0 else 0
        violation_rate = (self.constraint_violations / self.total_decisions) if self.total_decisions > 0 else 0
        
        return {
            "analysis_period": self.analysis_period,
            "period": {
                "start": self.period_start.isoformat(),
                "end": self.period_end.isoformat()
            },
            "metrics": {
                "total_decisions": self.total_decisions,
                "consistent_decisions": self.consistent_decisions,
                "consistency_rate": consistency_rate,
                "constraint_violations": self.constraint_violations,
                "violation_rate": violation_rate,
                "consistency_score": self.consistency_score
            },
            "trend": {
                "direction": self.trend_direction,
                "strength": self.trend_strength
            },
            "created_at": self.created_at.isoformat()
        }


class PhilosophyCommunityEvent(Base):
    """
    理念社區事件記錄
    """
    __tablename__ = "philosophy_community_events"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # 事件信息
    event_type = Column(String(100), nullable=False)  # council_meeting, review_completed, declaration_approved
    event_name = Column(String(200), nullable=False)
    description = Column(Text, nullable=True)
    
    # 參與者
    organizer_id = Column(UUID(as_uuid=True), ForeignKey("agents.id"), nullable=True)
    organizer = relationship("Agent", foreign_keys=[organizer_id])
    participants = Column(JSON, nullable=False, default=list)  # 參與者ID列表
    
    # 事件內容
    agenda = Column(JSON, nullable=True)
    discussion_topics = Column(JSON, nullable=True)
    decisions_made = Column(JSON, nullable=True)
    
    # 結果
    outcome = Column(JSON, nullable=True)
    action_items = Column(JSON, nullable=True)
    
    # 時間信息
    scheduled_start = Column(DateTime, nullable=True)
    scheduled_end = Column(DateTime, nullable=True)
    actual_start = Column(DateTime, nullable=True)
    actual_end = Column(DateTime, nullable=True)
    
    # 狀態
    status = Column(String(50), nullable=False, default="scheduled")  # scheduled, in_progress, completed, cancelled
    
    # 元數據
    is_public = Column(Boolean, nullable=False, default=True)
    attendance_count = Column(Integer, nullable=True)
    
    # 時間戳
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<PhilosophyCommunityEvent {self.id}: {self.event_type} - {self.event_name}>"
    
    @property
    def event_summary(self) -> Dict[str, Any]:
        """獲取事件摘要"""
        return {
            "event_type": self.event_type,
            "event_name": self.event_name,
            "status": self.status,
            "organizer_id": str(self.organizer_id) if self.organizer_id else None,
            "participants_count": len(self.participants),
            "scheduled_time": {
                "start": self.scheduled_start.isoformat() if self.scheduled_start else None,
                "end": self.scheduled_end.isoformat() if self.scheduled_end else None
            },
            "is_public": self.is_public,
            "created_at": self.created_at.isoformat()
        }


class PhilosophyMentorship(Base):
    """
    理念導師關係記錄
    """
    __tablename__ = "philosophy_mentorships"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # 導師與學徒關係
    mentor_id = Column(UUID(as_uuid=True), ForeignKey("agents.id"), nullable=False, index=True)
    mentor = relationship("Agent", foreign_keys=[mentor_id], back_populates="mentorships_as_mentor")
    
    apprentice_id = Column(UUID(as_uuid=True), ForeignKey("agents.id"), nullable=False, index=True)
    apprentice = relationship("Agent", foreign_keys=[apprentice_id], back_populates="mentorships_as_apprentice")
    
    # 關係信息
    relationship_type = Column(String(50), nullable=False, default="philosophy_guidance")  # philosophy_guidance, technical_coaching, community_integration
    match_reason = Column(Text, nullable=True)  # 匹配理由
    
    # 狀態
    status = Column(String(50), nullable=False, default="active")  # active, completed, paused, terminated
    is_official = Column(Boolean, nullable=False, default=False)  # 是否為官方認證的導師關係
    
    # 進度追蹤
    sessions_completed = Column(Integer, nullable=False, default=0)
    last_session_date = Column(DateTime, nullable=True)
    next_session_scheduled = Column(DateTime, nullable=True)
    
    # 評估
    mentor_rating = Column(Float, nullable=True)  # 學徒對導師的評分
    apprentice_rating = Column(Float, nullable=True)  # 導師對學徒的評分
    relationship_quality = Column(Float, nullable=True)  # 關係質量評分
    
    # 時間戳
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)
    
    # 持續時間
    duration_days = Column(Integer, nullable=True)  # 關係持續天數
    
    def __repr__(self):
        return f"<PhilosophyMentorship {self.id}: {self.mentor_id} -> {self.apprentice_id}>"
    
    @property
    def summary(self) -> Dict[str, Any]:
        """獲取關係摘要"""
        now = datetime.utcnow()
        days_active = (now - self.created_at).days if self.status == "active" else None
        
        return {
            "mentor_id": str(self.mentor_id),
            "apprentice_id": str(self.apprentice_id),
            "relationship_type": self.relationship_type,
            "status": self.status,
            "sessions_completed": self.sessions_completed,
            "days_active": days_active,
            "is_official": self.is_official,
            "created_at": self.created_at.isoformat()
        }