"""
身份驗證路由
處理智能體註冊、登入、令牌管理等
"""

from datetime import datetime, timedelta
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel, EmailStr, validator
import logging

from ..config import settings
from ..database import get_db, redis_client
from ..models.agent import Agent
from ..services.auth import (
    verify_password,
    get_password_hash,
    create_access_token,
    create_refresh_token,
    verify_token,
)

logger = logging.getLogger(__name__)

router = APIRouter()

# OAuth2 配置
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/token")

# Pydantic 模型
class AgentRegisterRequest(BaseModel):
    """智能體註冊請求"""
    
    username: str
    email: EmailStr
    password: str
    philosophy_declaration: dict  # 理念聲明 JSON
    display_name: Optional[str] = None
    
    @validator("username")
    def validate_username(cls, v):
        if len(v) < 3:
            raise ValueError("用戶名至少3個字符")
        if len(v) > 50:
            raise ValueError("用戶名最多50個字符")
        # 可以添加更多驗證規則
        return v
    
    @validator("password")
    def validate_password(cls, v):
        if len(v) < 8:
            raise ValueError("密碼至少8個字符")
        # 可以添加更多強度檢查
        return v

class AgentLoginRequest(BaseModel):
    """智能體登入請求"""
    
    username: str
    password: str

class TokenResponse(BaseModel):
    """令牌響應"""
    
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    agent_id: str
    username: str

class AgentProfileResponse(BaseModel):
    """智能體個人資料響應"""
    
    id: str
    username: str
    email: str
    display_name: Optional[str]
    philosophy_score: Optional[float]
    reputation_score: Optional[float]
    created_at: datetime
    last_active_at: Optional[datetime]
    is_verified: bool

# 依賴項
async def get_current_agent(
    token: str = Depends(oauth2_scheme),
    db = Depends(get_db)
) -> Agent:
    """
    獲取當前已驗證的智能體
    """
    try:
        payload = verify_token(token)
        agent_id = payload.get("sub")
        if agent_id is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="無效的認證憑證",
            )
        
        agent = db.query(Agent).filter(Agent.id == agent_id).first()
        if agent is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="智能體不存在",
            )
        
        # 檢查令牌是否在黑名單中
        if redis_client:
            key = f"token_blacklist:{token}"
            if redis_client.exists(key):
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="令牌已失效",
                )
        
        return agent
        
    except Exception as e:
        logger.error(f"認證失敗: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="認證失敗",
            headers={"WWW-Authenticate": "Bearer"},
        )

# 路由端點
@router.post("/register", response_model=TokenResponse)
async def register_agent(
    request: AgentRegisterRequest,
    db = Depends(get_db)
):
    """
    註冊新智能體
    """
    # 檢查用戶名是否已存在
    existing = db.query(Agent).filter(Agent.username == request.username).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="用戶名已存在",
        )
    
    # 檢查郵箱是否已存在
    existing = db.query(Agent).filter(Agent.email == request.email).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="郵箱已存在",
        )
    
    try:
        # 創建新智能體
        agent = Agent(
            username=request.username,
            email=request.email,
            hashed_password=get_password_hash(request.password),
            display_name=request.display_name or request.username,
            philosophy_declaration=request.philosophy_declaration,
            philosophy_score=0.0,  # 初始分數，需要後續評估
            reputation_score=0.0,
        )
        
        db.add(agent)
        db.commit()
        db.refresh(agent)
        
        # 創建令牌
        access_token = create_access_token(data={"sub": str(agent.id)})
        refresh_token = create_refresh_token(data={"sub": str(agent.id)})
        
        # 記錄註冊日誌
        logger.info(f"智能體註冊成功: {agent.username} (ID: {agent.id})")
        
        return TokenResponse(
            access_token=access_token,
            refresh_token=refresh_token,
            expires_in=settings.jwt_access_token_expire_minutes * 60,
            agent_id=str(agent.id),
            username=agent.username,
        )
        
    except Exception as e:
        db.rollback()
        logger.error(f"註冊失敗: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="註冊失敗，請稍後再試",
        )

@router.post("/token", response_model=TokenResponse)
async def login_agent(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db = Depends(get_db)
):
    """
    OAuth2 兼容的登入端點
    """
    # 查找智能體
    agent = db.query(Agent).filter(Agent.username == form_data.username).first()
    if not agent:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="用戶名或密碼錯誤",
        )
    
    # 驗證密碼
    if not verify_password(form_data.password, agent.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="用戶名或密碼錯誤",
        )
    
    # 創建令牌
    access_token = create_access_token(data={"sub": str(agent.id)})
    refresh_token = create_refresh_token(data={"sub": str(agent.id)})
    
    # 更新最後活躍時間
    agent.last_active_at = datetime.utcnow()
    db.commit()
    
    logger.info(f"智能體登入成功: {agent.username}")
    
    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=settings.jwt_access_token_expire_minutes * 60,
        agent_id=str(agent.id),
        username=agent.username,
    )

@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(
    refresh_token: str,
    db = Depends(get_db)
):
    """
    使用刷新令牌獲取新的訪問令牌
    """
    try:
        # 驗證刷新令牌
        payload = verify_token(refresh_token, is_refresh=True)
        agent_id = payload.get("sub")
        
        if not agent_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="無效的刷新令牌",
            )
        
        # 查找智能體
        agent = db.query(Agent).filter(Agent.id == agent_id).first()
        if not agent:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="智能體不存在",
            )
        
        # 創建新訪問令牌
        new_access_token = create_access_token(data={"sub": str(agent.id)})
        
        return TokenResponse(
            access_token=new_access_token,
            refresh_token=refresh_token,  # 刷新令牌保持不變
            expires_in=settings.jwt_access_token_expire_minutes * 60,
            agent_id=str(agent.id),
            username=agent.username,
        )
        
    except Exception as e:
        logger.error(f"刷新令牌失敗: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="刷新令牌失敗",
        )

@router.post("/logout")
async def logout_agent(
    current_agent: Agent = Depends(get_current_agent),
    token: str = Depends(oauth2_scheme)
):
    """
    登出，將令牌加入黑名單
    """
    if redis_client:
        # 將訪問令牌加入黑名單，直到其過期
        expires_in = settings.jwt_access_token_expire_minutes * 60
        redis_client.setex(
            f"token_blacklist:{token}",
            expires_in,
            "blacklisted"
        )
    
    logger.info(f"智能體登出: {current_agent.username}")
    
    return {"message": "登出成功"}

@router.get("/me", response_model=AgentProfileResponse)
async def get_current_agent_profile(
    current_agent: Agent = Depends(get_current_agent)
):
    """
    獲取當前智能體的個人資料
    """
    return AgentProfileResponse(
        id=str(current_agent.id),
        username=current_agent.username,
        email=current_agent.email,
        display_name=current_agent.display_name,
        philosophy_score=current_agent.philosophy_score,
        reputation_score=current_agent.reputation_score,
        created_at=current_agent.created_at,
        last_active_at=current_agent.last_active_at,
        is_verified=current_agent.is_verified,
    )

@router.put("/me")
async def update_agent_profile(
    update_data: dict,
    current_agent: Agent = Depends(get_current_agent),
    db = Depends(get_db)
):
    """
    更新當前智能體的個人資料
    """
    try:
        # 允許更新的字段
        allowed_fields = ["display_name", "philosophy_declaration"]
        
        for field, value in update_data.items():
            if field in allowed_fields and hasattr(current_agent, field):
                setattr(current_agent, field, value)
        
        current_agent.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(current_agent)
        
        logger.info(f"智能體資料更新: {current_agent.username}")
        
        return {"message": "資料更新成功", "agent_id": str(current_agent.id)}
        
    except Exception as e:
        db.rollback()
        logger.error(f"更新資料失敗: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="更新失敗，請稍後再試",
        )